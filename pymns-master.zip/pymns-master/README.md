pyMNS.py

Python Markov Network Solver

Ref: http://www.cs.huji.ac.il/project/UAI10/fileFormat.php

Version 0.4

1. Enlarged system recursion limit for t4.uai

June 5, 2013

Version 0.3

1. Added loopy Belief Propagation

May 30, 2013

Version 0.2

1. Added Variable Elimination algorithm

2. Added min-neighbors heuristic

3. Added support for evidence file

4. Added support for MAP inference

5. Added other ordering heuristics

May 12, 2013

Version 0.1

daveti@cs.uoregon.edu

http://daveti.blog.com
