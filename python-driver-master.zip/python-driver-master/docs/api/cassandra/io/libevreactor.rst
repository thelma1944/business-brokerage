``cassandra.io.libevreactor`` - ``libev`` Event Loop
====================================================

.. module:: cassandra.io.libevreactor

.. autoclass:: LibevConnection
