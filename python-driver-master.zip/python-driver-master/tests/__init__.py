import logging

log = logging.getLogger()
log.setLevel('DEBUG')
